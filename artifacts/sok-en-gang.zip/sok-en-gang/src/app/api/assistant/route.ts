import type { NextRequest } from 'next/server';
import { z } from 'zod';
import { CaseError } from '../../../server/case-service';
import { failure, json, readBody } from '../../../server/http';
import { createAssistantCase, deleteAssistantCase, loadAssistantCase, saveAssistantCase, withAssistantLock } from '../../../server/assistant-store';
import { ASSISTANT_COOKIE, assistantFrom, assistantResponse } from '../../../server/assistant-http';
import { addConfirmedAnswers, addMessage, analyzeCase, decideFactAndContinue, prepareHandoff } from '../../../server/assistant-service';
import { factKeys } from '../../../domain/assistant-types';

import { connectKs, consentAndReadIncome, declineKsAccess } from '../../../server/assistant-ks';

export const runtime = 'nodejs';
const revision = z.number().int().positive();
const caseId = z.string().uuid();
const schema = z.discriminatedUnion('action', [
  z.object({ action: z.literal('start') }).strict(),
  z.object({ action: z.literal('message'), message: z.string().trim().min(1).max(4000), revision, caseId }).strict(),
  z.object({ action: z.literal('answers'), message: z.string().trim().min(1).max(4000), answers: z.array(z.object({ key: z.enum(factKeys), value: z.string().trim().min(1).max(200), quote: z.string().trim().min(1).max(1000) }).strict()).min(1).max(8), revision, caseId }).strict(),
  z.object({ action: z.literal('analyze'), revision, caseId }).strict(),
  z.object({ action: z.literal('fact'), factId: z.string().uuid(), decision: z.enum(['confirm', 'reject']), revision, caseId }).strict(),
  z.object({ action: z.literal('connect-ks'), revision, caseId }).strict(),
  z.object({ action: z.literal('income-consent'), approved: z.literal(true), revision, caseId }).strict(),
  z.object({ action: z.literal('ks-access'), approved: z.boolean(), revision, caseId }).strict(),
  z.object({ action: z.literal('handoff'), confirmed: z.literal(true), revision, caseId }).strict(),
]);
export async function GET(request: NextRequest) {
  try { return await assistantResponse(assistantFrom(request)); }
  catch (error) { if (error instanceof CaseError && error.status === 401) return assistantResponse(null); return failure(error); }
}
export async function POST(request: NextRequest) {
  try {
    const command = await readBody(request, schema);
    if (command.action === 'start') {
      try { return await assistantResponse(assistantFrom(request)); }
      catch (error) { if (!(error instanceof CaseError && error.status === 401)) throw error; }
      const session = createAssistantCase();
      const response = await assistantResponse(session, 201);
      response.cookies.set(ASSISTANT_COOKIE, session.id, { httpOnly: true, sameSite: 'strict', secure: request.nextUrl.protocol === 'https:', path: '/', maxAge: 86400 });
      return response;
    }
    const current = assistantFrom(request);
    if (command.caseId !== current.id) throw new CaseError('En annen samtale er åpnet i en annen fane. Last inn siden på nytt.', 409);
    if (command.action === 'handoff' && current.handoff && command.revision === current.revision) return assistantResponse(current);
    await withAssistantLock(current.id, command.revision, async session => {
      if (command.action === 'message') { addMessage(session, command.message); await analyzeCase(session); }
      else if (command.action === 'answers') { addConfirmedAnswers(session, command.message, command.answers); await analyzeCase(session); }
      else if (command.action === 'analyze') { if (!session.messages.length) throw new CaseError('Beskriv hva du trenger hjelp med først.'); await analyzeCase(session); }
      else if (command.action === 'fact') await decideFactAndContinue(session, command.factId, command.decision);
      else if (command.action === 'connect-ks') { await connectKs(session); if (session.messages.length) await analyzeCase(session); }
      else if (command.action === 'income-consent') { await consentAndReadIncome(session, command.approved); if (session.messages.length) await analyzeCase(session); }
      else if (command.action === 'ks-access') {
        if (!command.approved) declineKsAccess(session);
        else {
          if (!session.ksData) await connectKs(session);
          await consentAndReadIncome(session, true);
          if (session.messages.length) await analyzeCase(session);
        }
      }
      else if (command.action === 'handoff') prepareHandoff(session, command.confirmed);
      saveAssistantCase(session);
    });
    return assistantResponse(loadAssistantCase(current.id));
  } catch (error) { return failure(error); }
}
export async function DELETE(request: NextRequest) {
  try {
    const command = await readBody(request, z.object({ caseId, revision }).strict());
    const current = assistantFrom(request);
    if (command.caseId !== current.id || command.revision !== current.revision) throw new CaseError('Samtalen er endret. Last inn siden før du sletter.', 409);
    deleteAssistantCase(current.id);
    const response = json({ deleted: true }); response.cookies.delete(ASSISTANT_COOKIE); return response;
  } catch (error) { return failure(error); }
}
