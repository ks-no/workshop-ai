'use client';

import { AssistantButton, AssistantIcon } from './assistant-controls';
import { factLabel, factValue, localizeCheck, serviceLabel, useAssistantLocale } from './assistant-i18n';
import { PktCheckbox, PktTabs, PktTag } from './punkt-react';
import { AssistantMarkdown } from './assistant-markdown';
import { AssistantPlanBoard } from './assistant-plan-board';
import { AssistantSfoAnswer } from './assistant-sfo-answer';

import { useState } from 'react';
import type { AssistantCase, AssistantCommand, MemoryFact, ServiceResult, FollowUp } from '../domain/assistant-types';
import { ore } from '../domain/format';
import { AssistantEvidence, AssistantSource } from './assistant-evidence';

type CaseAction = (command: AssistantCommand, label: string) => Promise<boolean>;
const factStatuses: Record<MemoryFact['status'], string> = { proposed: 'Til bekreftelse', confirmed: 'Bekreftet av deg', rejected: 'Avvist av deg', superseded: 'Erstattet', conflict: 'Motstridende opplysning' };
const serviceStatuses: Record<ServiceResult['status'], string> = { ready: 'Forberedt', 'needs-information': 'Trenger opplysninger', 'needs-review': 'Må vurderes av en person', error: 'Kunne ikke fullføres' };

export function AssistantCasePanel({ session, busy, modelAvailable, view, onViewChange, act, onQuestions }: {
  session: AssistantCase | null; busy: boolean; modelAvailable: boolean; act: CaseAction;
  view: 'overview' | 'board' | 'review'; onViewChange: (view: 'overview' | 'board' | 'review') => void;
  onQuestions: (questions: FollowUp[]) => void;
}) {
  const { locale, t, dateTime } = useAssistantLocale();
  const [confirmedVersion, setConfirmedVersion] = useState<string | null>(null);
  const consentVersion = session ? `${session.id}:${session.revision}` : null;
  const facts = session?.facts.filter(fact => !['rejected', 'superseded'].includes(fact.status)) ?? [];
  const historicFacts = session?.facts.filter(fact => ['rejected', 'superseded'].includes(fact.status)) ?? [];
  const unresolved = facts.filter(fact => ['proposed', 'conflict'].includes(fact.status));
  const personalized = session?.intent !== 'information';
  const stale = !!session && session.analyzedRevision !== session.revision;
  const completed = !!session?.services.length && session.services.every(service => !['error', 'needs-information'].includes(service.status));
  const canHandoff = !!session && !busy && !stale && !unresolved.length && completed && !session.handoff;
  const remaining = session?.services.flatMap(service => service.checks.filter(check => check.status !== 'ready').map(check => ({ ...localizeCheck(check, locale), service: serviceLabel(service.id, locale) }))) ?? [];

  function factAction(fact: MemoryFact, decision: 'confirm' | 'reject') {
    if (!session) return;
    setConfirmedVersion(null);
    const continues = unresolved.length === 1;
    void act({ action: 'fact', factId: fact.id, decision, revision: session.revision, caseId: session.id }, continues ? 'Oppdaterer planen automatisk' : decision === 'confirm' ? 'Lagrer bekreftelsen' : 'Avviser opplysningen');
  }

  return <div className="assistant-case-content">
    <div className="assistant-plan-tabs" aria-label={t('Planvisning')}><PktTabs tabs={[{ text: t('Oversikt'), active: view === 'overview', controls: 'assistant-overview' }, { text: t('Tavle'), active: view === 'board', controls: 'assistant-board' }, { text: t('Gjennomgang'), active: view === 'review', controls: 'assistant-review' }]} onTabSelected={index => onViewChange(index === 0 ? 'overview' : index === 1 ? 'board' : 'review')} /></div>
    {<div id="assistant-board" role="tabpanel" aria-label={t('Tavle')} hidden={view !== 'board'}><AssistantPlanBoard session={session} busy={busy} onQuestions={onQuestions} /></div>}
    <div id="assistant-overview" role="tabpanel" aria-label={t('Oversikt')} hidden={view !== 'overview'}>
    {session && personalized && <AssistantSfoAnswer session={session} />}
    <section className="assistant-case-section" aria-labelledby="case-heading">
      <div className="assistant-section-heading"><h2 id="case-heading" tabIndex={-1}>{t("Din felles oversikt")}</h2>{session && <span className="small">{t("Lagres i denne demoen")}</span>}</div>
      <p className="assistant-section-intro">{t("Opplysningene brukes på tvers av tjenestene. Du bestemmer hva som stemmer.")}</p>
      {session?.summary && <div className="assistant-case-summary"><p className="small">{t("KI-tolkning av situasjonen. Kontroller at den stemmer.")}</p><AssistantMarkdown text={session.summary} language={session.language || 'nb'} /></div>}
      {!facts.length && <div className="assistant-empty"><AssistantIcon name="document-text" aria-hidden="true"  /><p>{t("Når du forteller om situasjonen din, samler vi opplysninger her. Ingenting er bekreftet før du sier ja.")}</p></div>}
      {!!unresolved.length && <p className="assistant-inline-notice">{t("Se over")} {unresolved.length} {t('opplysninger')}. {t("Planen oppdateres automatisk når den siste er avklart.")}</p>}
      <div className="assistant-facts">{facts.map(fact => <article className={`assistant-fact ${fact.status === 'conflict' ? 'is-conflict' : ''}`} key={fact.id}>
        <div className="assistant-fact-main"><div className="assistant-fact-copy"><h3>{factLabel(fact.key, fact.label, locale)}</h3><p className="assistant-fact-value">{factValue(fact.value, locale)}</p></div><PktTag size="small" skin={fact.status === 'confirmed' ? 'green' : fact.status === 'conflict' ? 'yellow' : 'blue-light'}>{fact.status === 'confirmed' && <AssistantIcon name="check" aria-hidden="true"  />}{t(fact.status === 'confirmed' && session?.sources.some(source => source.id === fact.citation.sourceId && source.kind === 'register') ? 'Hentet fra KS' : factStatuses[fact.status])}</PktTag></div>
        {fact.status === 'conflict' && <p className="assistant-conflict-copy"><AssistantIcon name="alert-warning" aria-hidden="true"  />{t("Det finnes ulike verdier for denne opplysningen. Bekreft den korrigerte verdien. Når alle forslag er avklart, oppdateres planen automatisk.")}</p>}
        <div className="assistant-fact-footer"><AssistantEvidence citation={fact.citation} sources={session?.sources ?? []} />
        {!session?.handoff && <div className="assistant-fact-actions">
          {fact.status !== 'confirmed' && <AssistantButton skin="secondary" size="small" disabled={busy} onClick={() => factAction(fact, 'confirm')}>{t(unresolved.length === 1 ? fact.status === 'conflict' ? 'Bekreft korrigering og oppdater planen' : 'Bekreft og oppdater planen' : fact.status === 'conflict' ? 'Bekreft korrigering' : 'Bekreft')} <span className="sr-only">{factLabel(fact.key, fact.label, locale)}: {factValue(fact.value, locale)}</span></AssistantButton>}
          {fact.status !== 'confirmed' && <AssistantButton skin="tertiary" size="small" disabled={busy} onClick={() => factAction(fact, 'reject')}>{t("Avvis")}<span className="sr-only"> {factLabel(fact.key, fact.label, locale)}: {factValue(fact.value, locale)}</span></AssistantButton>}
          <AssistantButton skin="tertiary" size="small" disabled={busy} onClick={() => onQuestions([{ key: fact.key, question: factLabel(fact.key, fact.label, locale), serviceIds: [] }])}>{t("Rett opplysningen")}<span className="sr-only"> {factLabel(fact.key, fact.label, locale)}</span></AssistantButton>
        </div>}
        </div>
      </article>)}</div>
      {!!historicFacts.length && <details className="assistant-history-facts"><summary>{t("Avviste og erstattede opplysninger (")}{historicFacts.length})</summary>{historicFacts.map(fact => <div className="assistant-historic-fact" key={fact.id}><strong>{factLabel(fact.key, fact.label, locale)}: {factValue(fact.value, locale)}</strong><p className="small">{t(factStatuses[fact.status])}</p><AssistantEvidence citation={fact.citation} sources={session?.sources ?? []} /></div>)}</details>}
    </section>

    {!!session?.services.length && <section className="assistant-case-section" aria-labelledby="services-heading">
      <div className="assistant-section-heading"><h2 id="services-heading" tabIndex={-1}>{t(personalized ? "Planen din" : "Svar og kilder")}</h2>{stale && <span className="assistant-state">{t("Trenger oppdatering")}</span>}</div>
      {stale && <p className="assistant-inline-notice">{t("Opplysningene er endret. Oppdater planen for å bruke siste versjon.")}</p>}
      {session.services.map(service => <article className="assistant-service" key={service.id}>
        <div className="assistant-service-heading"><h3>{serviceLabel(service.id, locale)}</h3><PktTag size="small" skin={service.status === 'error' ? 'red' : 'blue-light'}>{t(serviceStatuses[service.status])}</PktTag></div>
        <p className="small">{t("KI-tolkning. Kontroller mot kildene og sjekklisten.")}</p><AssistantMarkdown text={service.summary} language={session.language || 'nb'} /><div className="small assistant-service-reason">{t("Hvorfor denne tjenesten (KI-tolkning):")} <AssistantMarkdown text={service.reason} language={session.language || 'nb'} /></div>
        {service.error && <p className="assistant-error" role="alert">{t(service.error)}</p>}
        <ul className="assistant-checks">{service.checks.map(original => { const check = localizeCheck(original, locale); return <li key={check.id}><span className={`assistant-check-status ${check.status === 'ready' ? 'is-ready' : ''}`}>{check.status === 'ready' ? <AssistantIcon name="check" aria-label={t("Klart")}  /> : t(check.status === 'human' ? 'Vurdering' : 'Mangler')}</span><div><strong>{check.label}</strong><p className="small">{check.detail}</p></div></li>; })}</ul>
        {service.assessment && <div className="assistant-assessment"><strong>{t(service.assessment.title)}</strong><p>{t(service.assessment.explanation)}</p>{service.assessment.calculation && <dl><div><dt>{t("Beregnet SFO-betaling")}</dt><dd>{ore(service.assessment.calculation.monthlyAfterOre)} {t("per måned")}</dd></div><div><dt>{t("Mat kommer i tillegg")}</dt><dd>{ore(service.assessment.calculation.monthlyFoodOre)} {t("per måned")}</dd></div></dl>}<p className="small">{t("Fast beregning i demoen ·")} {service.assessment.ruleVersion}</p></div>}
        {!!service.findings.length && <details className="assistant-findings"><summary>{t("Begrunnelse og kilder")}</summary><p className="small">{t("KI-tolkninger må kontrolleres. Et ordrett sitat viser hvor teksten finnes, men beviser ikke at tolkningen er riktig.")}</p>{service.findings.map((finding, i) => <div key={`${finding.citation.sourceId}-${i}`}><>{finding.text === finding.citation.quote ? <p>{finding.text}</p> : <AssistantMarkdown text={finding.text} language={session.language || 'nb'} />}</><AssistantEvidence citation={finding.citation} sources={session.sources} /></div>)}</details>}
      </article>)}
      {!session.handoff && (stale || session.status === 'error') && <AssistantButton skin="secondary" className="assistant-update" disabled={busy || !modelAvailable} onClick={() => { setConfirmedVersion(null); void act({ action: 'analyze', revision: session.revision, caseId: session.id }, 'Oppdaterer planen'); }}><AssistantIcon name="arrow-circle" aria-hidden="true"  />{t(session.status === 'error' ? "Prøv planen på nytt" : "Oppdater planen")}</AssistantButton>}
    </section>}

    {!!session?.unsupported.length && <section className="assistant-case-section"><h2>{t("Dette må du få hjelp med")}</h2><ul className="assistant-plain-list">{session.unsupported.map((item, i) => <li key={i} lang={session.language || 'nb'}>{item}</li>)}</ul><p className="small">{t("Demoen kan forberede familie/SFO, bolig og flytting. Andre tjenester er ikke koblet til.")}</p></section>}

    </div>

    <div id="assistant-review" role="tabpanel" aria-label={t('Gjennomgang')} hidden={view !== 'review'}>
    {!!session?.services.length && personalized && <section className="assistant-case-section assistant-handoff" aria-labelledby="handoff-heading">
      <h2 id="handoff-heading" tabIndex={-1}>{t(session.handoff ? 'Saken er klargjort lokalt' : 'Du har siste ord')}</h2>
      {session.handoff ? <><p>{t("Oppsummeringen er klar for at en person kan se over saken. Ingen søknad er sendt til kommunen.")}</p><p className="small">{t("Bekreftet")} {dateTime(session.handoff.createdAt)}</p><a className="pkt-btn pkt-btn--secondary pkt-btn--medium" href={`/api/assistant/receipt?caseId=${encodeURIComponent(session.id)}&revision=${session.revision}`} download><AssistantIcon name="download" aria-hidden="true"  />{t("Last ned saksgrunnlag (JSON)")}</a></> : <>
        <p>{t("Lag et lokalt saksgrunnlag med opplysningene, kildene og planen. Det er en forberedelse til videre hjelp, ikke et vedtak.")}</p>
        {!!remaining.length && <details className="assistant-remaining"><summary>{t("Dette gjenstår før videre behandling (")}{remaining.length})</summary><ul>{remaining.map((item, i) => <li key={`${item.service}-${item.id}-${i}`}><strong>{item.service}: {item.label}</strong><p>{item.detail}</p></li>)}</ul></details>}
        {!canHandoff && <p className="small">{t(unresolved.length ? 'Bekreft eller avvis opplysningene først.' : stale ? 'Oppdater planen med de siste opplysningene først.' : !completed ? 'Alle tjenestevurderinger må fullføres først.' : 'Vent til arbeidet er fullført.')}</p>}
        <PktCheckbox id="assistant-handoff-consent" className="assistant-confirm-choice" checked={confirmedVersion === consentVersion && canHandoff} disabled={!canHandoff} onChange={event => setConfirmedVersion(event.target.checked ? consentVersion : null)} label={t('Jeg har sett over opplysningene og det som gjenstår, og vil klargjøre saksgrunnlaget lokalt.')} />
        <AssistantButton skin="primary" disabled={!canHandoff || confirmedVersion !== consentVersion} onClick={() => { void act({ action: 'handoff', confirmed: true, revision: session.revision, caseId: session.id }, 'Klargjør saksgrunnlaget'); }}>{t("Bekreft og klargjør")}</AssistantButton>
        <p className="small">{t("Ingen søknad sendes. Saksgrunnlaget lagres bare i demoen.")}</p>
      </>}
    </section>}

    {!!session?.sources.length && <section className="assistant-case-section"><details className="assistant-all-sources"><summary><span>{t("Alle kildene dine")}</span><span className="small">{session.sources.length}</span></summary>{session.sources.map(source => <AssistantSource key={source.id} source={source} />)}</details></section>}
    {session && <p className="assistant-expiry small">{t("Saken lagres til")} {dateTime(session.expiresAt)}{t(". Du kan avslutte og slette den når som helst.")}</p>}
    </div>
  </div>;
}
