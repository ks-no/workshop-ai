/**
 * Punkt 18.4's published bundle creates a `window` alias on the Node global.
 * Remove only that exact server alias after loading so Next SSR keeps its normal
 * server/browser boundary. In a browser `window !== globalThis` is false because
 * both names point to the actual Window object and must remain available.
 */
import * as Punkt from '@oslokommune/punkt-react';
if (typeof window !== 'undefined' && window === globalThis && !('location' in window)) {
  Reflect.deleteProperty(globalThis, 'window');
}
export const { PktButton, PktCheckbox, PktIcon, PktProgressbar, PktRadioButton, PktSelect, PktTabs, PktTag, PktTextarea, PktTextinput } = Punkt;
export type { IPktButton } from '@oslokommune/punkt-react';
