# Søk én gang · Team Oslo

Hackathondemo for én samtale som kan forberede familie/SFO, bolig og flytting. Bruk bare testopplysninger. Ingen søknad sendes.

## Arkitektur

- Next.js/React med Oslo kommunes Punkt-designsystem og NO/EN-grensesnitt.
- Python og Microsoft Agent Framework: Qwen koordinerer, Gemma kjører faglige delanalyser via Cloudflare AI Gateway.
- SQLite-minne i 24 timer, kildeutdrag, revisjoner og eksplisitt bekreftelse av fakta.
- Agenten finner relevante tjenester fra friteksten. Generelle spørsmål besvares uten personoppslag; når en personlig SFO-vurdering trenger KS-data, vises et samtykke som neste steg i samtalen.
- Offisielle KS workshop-API-er kjøres lokalt. Ett uttrykkelig ja henter syntetisk husstand, SFO, inntekt og regelvurdering og fortsetter analysen automatisk. Et nei åpner manuelle spørsmål.
- KI kan forklare og foreslå. Den kan ikke bekrefte fakta, gi vedtak eller sende en søknad.

## Kjør lokalt

Krav: Node.js 22.18 eller nyere og Python 3.11 eller nyere.

```bash
npm ci
npm run setup:backend
npm run setup:ks
```

Kopier `.env.example` til `.env.local` og fyll inn Cloudflare-konto og token. Start KS-tjenestene i én terminal:

```bash
npm run start:ks
```

Start appen i en annen:

```bash
npm run dev
```

Åpne <http://127.0.0.1:3210/>. Dokumentasjonen og de fem diagrammene ligger på <http://127.0.0.1:3210/dokumentasjon>.

Standard testperson er `person-022`. Dette kan endres med `KS_PERSON_ID`, men appen tilbyr ingen testpersonvelger. KS-kildene er syntetiske workshopdata, ikke offentlige registre.

## Verifisering

```bash
npm test
npm run test:backend
npm run typecheck
npm run lint
npm run build
npm run test:e2e
```

Kort vietnamesisk veiledning: [docs/chay-nhanh.md](docs/chay-nhanh.md). Arkitektur og grenser: [docs/agentic-architecture.md](docs/agentic-architecture.md).
