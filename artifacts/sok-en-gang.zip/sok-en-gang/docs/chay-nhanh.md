# Chạy thử Søk én gang

Yêu cầu Node.js 22.18+ và Python 3.11+.

```bash
npm ci
npm run setup:backend
npm run setup:ks
cp .env.example .env.local
```

Điền `CF_ACCOUNT_ID` và `CF_AI_GATEWAY_TOKEN` trong `.env.local`. Mở terminal thứ nhất:

```bash
npm run start:ks
```

Mở terminal thứ hai:

```bash
npm run dev
```

Truy cập <http://127.0.0.1:3210/> và mô tả nhu cầu bằng tiếng Na Uy, Anh hoặc Việt; tiếng Na Uy là mặc định. Không cần chọn category. Agent tự nhận diện SFO, nhà ở hoặc chuyển nhà và có thể chọn nhiều dịch vụ từ cùng một tin nhắn.

Với câu hỏi kiến thức chung, agent trả lời từ hướng dẫn công khai mà không lấy dữ liệu cá nhân. Khi một đánh giá SFO cá nhân cần dữ liệu KS, một thẻ **Handling kreves** xuất hiện ngay trong hội thoại. Đồng ý một lần để lấy household, SFO, income và rule result của testperson `person-022`; phân tích tiếp tục tự động. Nếu từ chối, app không gọi KS và hiện các câu hỏi để nhập tay.

Kiểm tra các fact AI đề xuất, nguồn, checklist và bảng kế hoạch trước khi xác nhận. Kết quả cuối chỉ là gói JSON local; không gửi hồ sơ.

Trang tài liệu và 5 sơ đồ: <http://127.0.0.1:3210/dokumentasjon>.
