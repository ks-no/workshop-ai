# Hướng dẫn chạy và thử demo

Hướng dẫn hiện hành được giữ tại [chay-nhanh.md](chay-nhanh.md). Luồng `/sfo` cũ đã được gỡ; ứng dụng hiện dùng trợ lý ở trang chính và gọi KS workshop API local với testdata có nguồn.
