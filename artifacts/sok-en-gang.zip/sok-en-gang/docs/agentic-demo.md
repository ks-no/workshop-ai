# Chạy và trình diễn trợ lý Søk én gang

Trang `/` là trợ lý hội thoại cho gia đình/SFO, nhà ở và chuyển nhà. Trợ lý dùng
Cloudflare AI Gateway và Workers AI để chọn dịch vụ và phân tích từng mảng.
Microsoft Agent Framework chạy luồng agent trong Python: Qwen điều phối và
chọn dịch vụ; Gemma xử lý từng dịch vụ được chọn. Giao diện dùng Punkt.
Bộ nhớ hồ sơ vẫn nằm local. Mở [Tài liệu trong ứng dụng](http://127.0.0.1:3210/dokumentasjon)
để đọc hướng dẫn NO/EN và xem năm sơ đồ.
Chỉ dùng thông tin giả khi thử demo.

## Khởi động

Cần Node.js từ 22.18, npm, Python từ 3.11, kết nối mạng và tài khoản Cloudflare
có quyền gọi mô hình qua AI Gateway. Tại thư mục chứa `package.json`, tạo `.env.local` với các
biến dưới đây và điền ID tài khoản cùng token riêng trên máy chủ:

```dotenv
CF_ACCOUNT_ID=
CF_AI_GATEWAY_TOKEN=
LLM_MODEL=workers-ai/@cf/google/gemma-4-26b-a4b-it
LLM_COORDINATOR_MODEL=@cf/qwen/qwen3.8-27b
LLM_SPECIALIST_MODEL=@cf/google/gemma-4-26b-a4b-it
CF_AI_GATEWAY_ID=default
ASSISTANT_MODEL_TIMEOUT_MS=90000
ASSISTANT_DATA_DIR=.data
```

Không đặt token trong mã frontend hoặc chia sẻ file `.env.local`. Hai biến theo
vai trò chọn Qwen cho điều phối và Gemma cho chuyên gia trong ví dụ trên. Nếu
một vai trò không có biến riêng, app dùng `LLM_MODEL`; nếu cả biến riêng và biến
chung đều không có, app dùng Qwen/Gemma tương ứng. Vì vậy, cấu hình cũ chỉ có
`LLM_MODEL` vẫn dùng mô hình đó cho cả hai vai trò. `ASSISTANT_DATA_DIR` chọn thư mục bộ nhớ local;
đường dẫn tương đối tính từ thư mục chạy app. Xem [.env.example](../.env.example)
và [adapter thực tế](../src/server/assistant-model.ts) để đối chiếu các biến
được hỗ trợ.

Token cần quyền **Account → Workers AI → Read** cho endpoint đang dùng; chỉ có
quyền quản trị AI Gateway chưa đủ. `CF_AI_GATEWAY_ID` có thể bỏ qua để dùng
`default`. Xem [REST API của Cloudflare](https://developers.cloudflare.com/ai-gateway/usage/rest-api/).

```bash
npm ci
npm run setup:backend
npm run dev
```

`setup:backend` tạo môi trường riêng tại `backend/.venv`, cài các phiên bản
trong [backend/requirements.txt](../backend/requirements.txt), rồi kiểm tra import.
Nếu cần chọn Python riêng, dùng `PYTHON=python3.13 npm run setup:backend` với
phiên bản đã cài trên máy. Sau đó `dev` hoặc `start` tự tạo một tiến trình Python
cho mỗi lượt phân tích; không cần chạy thêm server hoặc mở cổng khác.

Để dùng dữ liệu KS, cài workshop chính thức rồi chạy ba dịch vụ local trong một
terminal riêng:

```bash
npm run setup:ks
npm run start:ks
```

Giữ terminal đó mở khi demo và dừng bằng **Ctrl+C** khi xong. Script dùng bản
nguồn KS được ghim trong [cấu hình workshop](../scripts/ks-workshop-config.mjs),
khởi động backend `8080`, Fiks `8081`, Digdir `8086` và dừng nếu các cổng đã có
chủ. Không tự chuyển sang cổng khác. Các giá trị mặc định trong `.env.example`:

```dotenv
KS_BACKEND_BASE_URL=http://127.0.0.1:8080
KS_FIKS_BASE_URL=http://127.0.0.1:8081
KS_DIGDIR_BASE_URL=http://127.0.0.1:8086
KS_DIGDIR_ISSUER=http://localhost:8086
KS_PERSON_ID=person-022
```

`KS_WORKSHOP_DIR` có thể trỏ tới thư mục workshop chính thức đã cài; mặc định là
`.runtime/ks-workshop`. Các API dùng dữ liệu tổng hợp và token thử nghiệm có chữ
ký; đây không phải đăng nhập BankID. AI của app vẫn gọi Qwen/Gemma qua Cloudflare.

Mở [Søk én gang](http://127.0.0.1:3210). Nếu app đang chạy, mở bản hiện có. Dừng
tiến trình do mình chạy bằng **Ctrl+C** trước khi khởi động lại. Sau khi đổi cấu
hình, restart app. Để dùng bản đã build, dừng bản dev rồi chạy `npm run build`
và `npm start`. Các lệnh có chủ sở hữu trong [package.json](../package.json).

Khi đã cấu hình đủ, màn hình hiện **Språkmodellen er konfigurert**. Mở **Om tilkoblingen**
để kiểm tra provider, mô hình và trạng thái. Lịch sử lượt agent lưu tên mô hình
thực tế đã chọn cho từng lượt. Nếu thấy **Språkmodellen er
ikke tilgjengelig**, kiểm tra cấu hình Cloudflare và kết nối mạng rồi bấm
**Kontroller tilkoblingen**. App không giả vờ đã chạy AI bằng câu trả lời có sẵn.
Một cấu hình có đủ biến chưa chứng minh lần gọi mô hình sẽ thành công: lỗi quyền,
hạn mức hoặc phản hồi không hợp lệ vẫn được báo rõ trong lượt phân tích.

Khi phân tích, app gửi phần hội thoại, văn bản tài liệu và thông tin cần thiết
sang Cloudflare. Mỗi chuyên gia chỉ nhận phần phù hợp với dịch vụ của mình.
SQLite vẫn lưu ở máy chạy app; việc này không có nghĩa mô hình chạy offline.

Để kiểm tra bằng dữ liệu giả với mô hình Cloudflare thật, chạy `npm run test:ai`.
Lệnh này dùng `.env.local`, gửi yêu cầu thật và có thể phát sinh phí. Khi chỉ
cần chạy lại tình huống tiếng Na Uy đang lỗi, dùng
`ASSISTANT_EVAL_FILTER=Norwegian npm run test:ai`; bỏ bộ lọc để kiểm tra đầy đủ.
Các tình huống và kết quả được định nghĩa trong
[bài đánh giá AI](../scripts/evaluate-assistant.mts).
Để kiểm tra riêng ngôn ngữ trả lời và giữ nguyên trích dẫn, chạy
`npm run test:ai:language`. Bài này cũng dùng Qwen/Gemma thật qua cấu hình trên.

Nếu câu trả lời sai định dạng, app có thể yêu cầu mô hình sửa một lần trong cùng
thời hạn ban đầu, mặc định 90 giây cho mỗi lượt agent. Kết quả sửa vẫn phải qua
kiểm tra `jsonschema` trong Python và Zod trong Node trước khi dùng. Lỗi HTTP
hoặc mất kết nối không tự kích hoạt lần thử lại. Node cũng giới hạn toàn bộ
tiến trình phân tích, mặc định 210 giây.

## Chọn giao diện và cách trả lời

Trong **Grensesnittspråk / Interface language**, chọn **NO – Norsk** hoặc
**EN – English**. Mặc định là tiếng Na Uy; lựa chọn giao diện được nhớ trong
trình duyệt. Các tên nút trong hướng dẫn bên dưới dùng giao diện NO.

Ngôn ngữ giao diện tách khỏi ngôn ngữ hội thoại: đổi NO/EN không dịch lại tin
nhắn cũ hoặc nguồn trích dẫn. Trả lời AI theo tin nhắn mới nhất hoặc yêu cầu ngôn
ngữ cụ thể. Ví dụ tiếng Việt ở phần sau vẫn nhận câu trả lời tiếng Việt khi
giao diện là NO hoặc EN.

## Demo đầy đủ: một nhu cầu, ba dịch vụ

1. Trong **Hva er situasjonen din?**, nhập đoạn sau và bấm **Send melding**.
   Sự kiện gửi đầu tiên tạo hồ sơ nếu chưa có, hoặc tiếp tục hồ sơ còn hạn của
   trình duyệt. Nó không tự xóa một hồ sơ đã mở ở tab khác.

   > Jeg har mistet jobben. Jeg har barn som bruker SFO, trenger hjelp med
   > boligutgiftene og planlegger å flytte til en annen kommune. Hva bør jeg
   > ordne først?

2. Mở **Se arbeidet som pågår** trong lúc chờ, hoặc **Se hva som har skjedd**
   để xem lịch sử. Xem lựa chọn dịch vụ, các lượt phân tích và nguồn đã
   đọc. Kết quả hướng tới **Familie og SFO**, **Bolig og bostøtte**, **Flytting**.
   Lựa chọn thực tế do mô hình thực hiện; câu chữ có thể khác giữa các lượt.

3. Trong **Din felles oversikt**, mở **Se kilde** bên cạnh từng thông tin.
   Kiểm tra trích dẫn, dòng, loại nguồn, thời điểm và mục đích. Bấm **Bekreft**
   khi đúng; **Avvis** khi mô hình hiểu sai. Có con không tự đồng nghĩa với dùng
   SFO. Phần này là người dùng xác nhận, không phải xác minh qua cơ quan nhà nước.

4. Trả lời các câu hỏi còn thiếu trong **Skriv en melding**, chẳng hạn:

   > Hele husholdningens brutto årsinntekt er 390 000 kroner. Vi er 3 personer i
   > husholdningen. Ingen samboer mangler i grunnlaget. Jeg skal flytte til Bergen
   > kommune den 2026-10-01.

   Cũng có thể điền biểu mẫu **Dette trenger vi å vite**: chọn Có/Không, loại
   thu nhập, nhập số tiền, số người, ngày hoặc nội dung tự do tùy câu hỏi.
   Mở **Se meldingen før sending** để đọc câu sẽ gửi, rồi bấm **Send svar**.
   Trường trống không được gửi. Câu trả lời vào hội thoại như một nguồn mới và
   vẫn phải qua bước đề xuất → **Bekreft / Avvis**; điền biểu mẫu không tự xác
   nhận thông tin. Câu trong biểu mẫu được soạn theo ngôn ngữ giao diện.

   Kiểm tra các đề xuất mới rồi xác nhận. Thu nhập hộ gia đình được dùng lại
   giữa SFO và nhà ở. Số tiền một tháng hoặc thu nhập một cá nhân không được
   mặc nhiên biến thành thu nhập cả năm của cả hộ.

5. Thử tài liệu nguồn ở phần tiếp theo để bổ sung tiền thuê nhà. Khi đã kiểm tra
   thông tin mới, bấm **Oppdater planen**. Sau mỗi thay đổi, kế hoạch cần phân
   tích lại để dùng đúng phiên bản thông tin hiện tại. Mỗi lần phân tích tạo phiên
   bản mới, kể cả khi dữ liệu đầu vào không đổi.

6. Đọc **Planen din**. Mỗi dịch vụ có lý do được chọn, checklist, điểm cần người
   xử lý và **Begrunnelse og kilder**. Nhà ở chỉ chuẩn bị chứng từ và bước tiếp
   theo; không tính số tiền bostøtte. Chuyển nhà chỉ chuẩn bị thông tin và nhắc
   người dùng mở dịch vụ chính thức. Trong khung kế hoạch, chọn **Oversikt**
   để đọc đầy đủ hoặc **Tavle** để xem checklist theo dịch vụ. **Svar eller rett
   opplysninger** mở các câu hỏi tương ứng; **Kilder for tjenesten** mở nguồn
   của dịch vụ. Trạng thái trên bảng lấy từ hồ sơ và quy tắc hiện tại.

Câu trả lời có thể hiển thị Markdown: tiêu đề, danh sách, đoạn trích, bảng và
liên kết. Bảng rộng cuộn được. HTML thô, ảnh nhúng và đường dẫn thực thi không
được hiển thị. Việc trình bày rõ hơn không thay thế kiểm tra ý nghĩa và nguồn.

Phần **KI-tolkning** là diễn giải do mô hình tạo và cần người dùng kiểm tra.
Trích dẫn nguyên văn chỉ xác định nguồn câu chữ, không tự chứng minh diễn giải
đúng. App có kiểm tra giới hạn với số chưa có trong nguồn và một số câu khẳng
định đã nộp đơn/được duyệt; đây không phải bộ kiểm chứng ý nghĩa hoàn chỉnh.
Checklist và phép tính SFO là kết quả của công cụ theo quy tắc cố định.

## Tài liệu nguồn thực sự được đọc

Tạo tệp UTF-8 `demo-grunnlag.txt` với nội dung giả dưới đây:

```text
Syntetisk dokument til demonstrasjon. Ingen virkelige personer.
Jeg betaler 12 500 kroner i husleie per måned.
Leieavtalen gjelder boligen jeg bor i nå.
```

Bấm **Legg ved dokument** → **Velg et dokument** → chọn tệp → **Last opp og
analyser**. Mở **Se kilde** tại đề xuất tiền thuê nhà: số tiền phải truy ngược
được về câu trong tệp. Mở **Les lagret kildetekst** để xem văn bản đã lưu.

Cũng có thể tải PDF có lớp văn bản. PDF được trích xuất thành văn bản theo trang;
**Se kilde · side …** hiển thị trang và dòng của bản trích xuất. PDF scan chỉ có
ảnh không được OCR. Mỗi tệp tối đa 1,5 MB, PDF tối đa 10 trang và văn bản trích
xuất tối đa 14.000 ký tự; mỗi hồ sơ nhận tối đa 4 tài liệu. Không coi việc upload
thành công là việc mọi thông tin đã
đúng: người dùng vẫn phải xác nhận từng đề xuất. Tài liệu không có quyền ra
lệnh cho agent; chỉ được dùng như nguồn dữ liệu.

## Thử mâu thuẫn, phủ định và cách nhớ

Sau khi đã xác nhận thu nhập, gửi:

> Jeg må rette husholdningens brutto årsinntekt. Riktig beløp er 360 000 kroner,
> ikke 390 000 kroner.

Giá trị mới phải qua **Motstridende opplysning** nếu khác giá trị đã xác nhận.
Bấm **Bekreft** ở giá trị muốn dùng, hoặc **Avvis** nếu muốn giữ giá trị trước.
Xem **Avviste og erstattede opplysninger** để thấy lịch sử. Với thông tin đã
xác nhận, dùng **Rett opplysningen** để soạn một tin nhắn sửa thông tin, rồi
kiểm tra và xác nhận đề xuất thay thế. Sau đó dùng **Oppdater planen**.

Để thử khả năng phân biệt phủ định và giả định, bắt đầu một hồ sơ mới và nhập:

> Jeg har ikke mistet jobben og bruker ikke SFO. Jeg spør bare hva jeg bør gjøre
> hvis jeg flytter senere; ingen flyttedato er bestemt.

Mô hình không được xem mất việc hay một ngày chuyển nhà cụ thể là sự thật đã
xác nhận. Nếu đề xuất sai, **Avvis** nó; nguồn trích dẫn không thay thế kiểm tra
ý nghĩa của người dùng.

Tiếng Na Uy Bokmål là mặc định. Trợ lý chọn ngôn ngữ trả lời theo tin nhắn mới
nhất do người dùng viết, hoặc theo yêu cầu ngôn ngữ cụ thể. Ví dụ, nhập:

> Tôi cần chuẩn bị giấy tờ về chi phí nhà ở. Hãy trả lời bằng tiếng Việt.

Phần trả lời và câu hỏi do AI tạo sẽ dùng tiếng Việt. Có thể chuyển lại bằng
**Svar på norsk bokmål, takk.** Tin nhắn ngắn hoặc mơ hồ giữ ngôn ngữ đang dùng;
tải tài liệu tiếng khác không tự đổi ngôn ngữ trả lời. Hồ sơ nhớ lựa chọn này
cho các lượt tiếp theo. Trích dẫn vẫn giữ nguyên ngôn ngữ nguồn để đối chiếu.
Các nút, tên thông tin và checklist dùng ngôn ngữ giao diện NO/EN; phần diễn
giải và câu hỏi do AI tạo dùng ngôn ngữ hội thoại. Nguồn gốc và một số nội dung
quy tắc vẫn giữ nguyên văn bản gốc.

Reload trang giữ hồ sơ còn hạn. Restart app cũng giữ hồ sơ nếu cùng datakatalog
và cookie trình duyệt. SQLite lưu tại `.data/assistant.sqlite` theo mặc định.
Hồ sơ hết hạn 24 giờ từ lúc tạo; hoạt động mới không gia hạn mốc này. App giữ tối
đa 20 tin nhắn gần nhất, còn nguồn và lịch sử thông tin là các phần riêng. Nếu
restart giữa một lượt phân tích, dữ liệu đã lưu được giữ, nhưng lượt đang dở
được báo lỗi và cần chạy lại. Bộ nhớ nằm trong SQLite của Node; tiến trình
Python mới không khôi phục từ checkpoint riêng của framework.

## Agent tự điều hướng và xin quyền KS đúng lúc

Người dùng không chọn category. Họ mô tả nhu cầu tự nhiên; Qwen nhận diện SFO,
nhà ở, chuyển nhà hoặc nhiều dịch vụ cùng lúc. Với câu hỏi kiến thức chung, agent
trả lời từ hướng dẫn công khai và không mở flow dữ liệu cá nhân.

Khi người dùng muốn đánh giá SFO theo tình huống của mình, hội thoại hiện thẻ
**Handling kreves**. Thẻ giải thích dữ liệu, nguồn KS workshop, mục đích và danh
tính test. Nếu người dùng đồng ý, một action duy nhất gọi các API local để lấy
household, SFO, rates, đăng ký/kiểm tra consent qua Fiks-simulator, lấy income và
rule result cho `person-022`, rồi tự động chạy lại agent với nguồn mới. Không cần
bấm **Oppdater planen**. Dữ liệu này là dữ liệu tổng hợp của workshop; không đọc
Folkeregisteret hoặc Skatteetaten thật.

Nếu người dùng từ chối, app không gọi KS và hiện câu hỏi để nhập tay. Đồng ý lấy
dữ liệu vẫn không tự xác nhận mọi đề xuất của AI hay kế hoạch cuối. Người dùng có
thể sửa thông tin KS khi tình huống thực tế khác; thay đổi trong hội thoại không
sửa cơ sở dữ liệu KS và cần được con người kiểm tra.

Nếu KS không chạy sau khi người dùng đồng ý, app báo lỗi; không thay bằng bộ dữ
liệu viết sẵn trong app. Hồ sơ vẫn được giữ để thử lại hoặc tiếp tục thủ công.

## Xác nhận kế hoạch cuối

Trong **Du har siste ord**, đọc **Dette gjenstår før videre behandling**. Khi
không còn đề xuất/mâu thuẫn chưa xử lý và phân tích đã hoàn tất với phiên bản
hiện tại, đánh dấu:

> Jeg har sett over opplysningene og det som gjenstår, og vil klargjøre
> saksgrunnlaget lokalt.

Bấm **Bekreft og klargjør**. **Last ned saksgrunnlag (JSON)** tải saksgrunnlag
và biên nhận local. Trạng thái này có thể vẫn liệt kê chứng từ và việc cần cán
bộ xem xét. Không có đơn nào được gửi đến kommune, Husbanken hay Skatteetaten.
Hồ sơ đã xác nhận được khóa để giữ nguyên phiên bản; muốn sửa tiếp thì bắt đầu
một cuộc hội thoại mới.

Kết thúc demo bằng **Avslutt og slett** → **Slett saken**. Hồ sơ cùng nguồn,
văn bản trích xuất và lịch sử được xóa khỏi kho local. Tệp JSON đã tải về máy
và bản tài liệu gốc người dùng đang giữ không bị xóa theo. Lịch sử và đồng ý
đã ghi ở KS-sandbox cũng không bị xóa hay thu hồi bằng thao tác này.

## Xem sơ đồ hoặc xử lý lỗi

Mở [bộ 5 sơ đồ](../public/diagrams/index.html), chọn từng tab, phóng to và tải
SVG hoặc nguồn Mermaid. HTML này xem được offline, không cần app chạy.

| Hiện tượng | Cách xử lý |
|---|---|
| Python chưa sẵn sàng | Chạy `npm run setup:backend` với Python 3.11+ rồi thử lại. Không cần khởi động một Python server riêng. |
| Không kết nối được AI | Kiểm tra biến Cloudflare, quyền token và kết nối mạng. Mở **Om tilkoblingen** rồi **Kontroller tilkoblingen**. |
| Mô hình trả lời quá lâu hoặc sai cấu trúc | Giữ hồ sơ, rút gọn mô tả hoặc bấm **Oppdater planen** để thử lại. Không coi lượt lỗi là phân tích hoàn tất. |
| Nút xác nhận cuối chưa dùng được | Xử lý mọi đề xuất/mâu thuẫn, cập nhật kế hoạch và đợi các phân tích hoàn tất. Sau đó đánh dấu ô xác nhận. |
| Hồ sơ thay đổi ở tab khác | Reload để lấy đúng hồ sơ và phiên bản mới nhất trước khi tiếp tục. Xác nhận ở tab cũ không được áp dụng cho hồ sơ khác. |
| Tệp không đọc được | Dùng TXT UTF-8 hoặc PDF có lớp văn bản; không dùng scan ảnh. Thông tin đã lưu trước lỗi vẫn được giữ. |
| Hồ sơ hết hạn | Bắt đầu cuộc hội thoại mới. Đây không phải hệ thống lưu hồ sơ lâu dài. |

Khi đóng gói mã nguồn để chia sẻ, bỏ `backend/.venv`, `node_modules`, `.next`,
`.data`, `.runtime` và các tệp `.env*` chứa cấu hình riêng; giữ `.env.example` làm mẫu. Máy
nhận chạy lại các bước cài đặt ở trên.

Xem [kiến trúc](agentic-architecture.md) để hiểu ranh giới nguồn, mô hình và
quyền xác nhận. Các giới hạn này là một phần của demo: chưa có BankID, hồ sơ
nhà nước, nộp đơn thật hay quyết định quyền lợi tự động.
